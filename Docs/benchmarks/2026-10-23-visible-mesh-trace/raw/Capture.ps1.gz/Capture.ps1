# @file    Capture.ps1
# @brief   Capture three isolated visible-mesh trials in one owned WPR instance and persist every capture phase.
# @author  Hasegawa Jin
# @date    2026-10-23
$ErrorActionPreference='Stop'
$task=$PSScriptRoot
$root=[IO.Path]::GetFullPath((Join-Path $task '..\..'))
$trace=Join-Path $task 'TraceV2'
[IO.Directory]::CreateDirectory($trace) | Out-Null
$state=[ordered]@{startedUtc=[DateTime]::UtcNow.ToString('o');finishedUtc=$null;phase='entered';elevated=$false;traceStarted=$false;traceStopped=$false;startExit=$null;stopExit=$null;failure=$null;runs=@()}
function Save-State {[IO.File]::WriteAllText("$trace\State.json",($state | ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))}
Save-State
$wpr='C:\Windows\System32\wpr.exe'
$instance='FBZZVisibleMeshTail20261023V2'
$started=$false
try {
    $principal=[Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
    $state.elevated=$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if(-not $state.elevated){throw 'CPU tracing requires an elevated process; the launcher did not obtain it'}
    if(Test-Path -LiteralPath "$trace\Cpu.etl"){throw 'Preserve the existing trace; capture already exists'}
    $status=(& $wpr -status -instancename $instance 2>&1 | Out-String)
    $statusExit=$LASTEXITCODE
    [IO.File]::WriteAllText("$trace\WprStatusBefore.txt",$status)
    if($statusExit -ne 0 -or $status -notmatch 'WPR is not recording'){throw 'Own recording instance is active or unverified; no recording was stopped'}
    [IO.Directory]::CreateDirectory("$trace\Temp") | Out-Null
    $state.phase='starting';Save-State
    & $wpr -start CPU -filemode -recordtempto "$trace\Temp" -instancename $instance *> "$trace\WprStart.txt"
    $state.startExit=$LASTEXITCODE
    if($state.startExit -ne 0){throw "WPR CPU start failed $($state.startExit)"}
    $started=$true;$state.traceStarted=$true;Save-State
    Add-Type -Path "$root\Scratch\StaticMeshReuse20261023\TaskProcessSettings.cs"
    $env:FBZZ_REGULAR_MESH_WARMUP='600';$env:FBZZ_REGULAR_MESH_SAMPLES='600'
    $env:FBZZ_REGULAR_MESH_TIMING_ONLY='1';$env:FBZZ_REGULAR_MESH_THREAD_CYCLES='1'
    for($run=0;$run -lt 3;++$run){
        $state.phase="trial-$run";Save-State
        $exe="$task\TraceRuntime\FBZZTestsRayTracingEngine.exe"
        $process=Start-Process -FilePath $exe -WindowStyle Hidden -PassThru -WorkingDirectory $root -ArgumentList @('--gtest_filter=RegularMeshRenderPerformanceTest.AllVisible1000',"--gtest_output=json:$trace/r$run-tests.json") -RedirectStandardOutput "$trace\r$run.out" -RedirectStandardError "$trace\r$run.err"
        $null=$process.Handle
        $process.ProcessorAffinity=[IntPtr]240;$process.PriorityClass='High'
        if([TaskProcessSettings]::SetHighQos($process.Id) -ne 0){throw 'Owned benchmark HighQoS verification failed'}
        $process.WaitForExit()
        $state.runs+=@{run=$run;pid=$process.Id;exit=$process.ExitCode}
        Save-State
        if($process.ExitCode -ne 0){throw "Native trial $run failed: $($process.ExitCode)"}
    }
} catch {
    $state.failure=$_.Exception.ToString()
} finally {
    if($started){
        $state.phase='stopping';Save-State
        & $wpr -stop "$trace\Cpu.etl" 'FBZZ visible-mesh tail CPU diagnosis' -skipPdbGen -instancename $instance *> "$trace\WprStop.txt"
        $state.stopExit=$LASTEXITCODE
        $state.traceStopped=$state.stopExit -eq 0 -and (Test-Path -LiteralPath "$trace\Cpu.etl")
        if(-not $state.traceStopped){$state.failure=[string]$state.failure+'; own WPR stop failed'}
    }
    $state.finishedUtc=[DateTime]::UtcNow.ToString('o')
    $state.phase=if(-not $state.failure -and $state.traceStopped){'complete'}else{'failed'}
    Save-State
}
if($state.phase -ne 'complete'){exit 1}
