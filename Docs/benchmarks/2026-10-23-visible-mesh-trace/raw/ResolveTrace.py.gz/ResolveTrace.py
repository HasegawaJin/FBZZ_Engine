# @file    ResolveTrace.py
# @brief   Resolve measured-frame samples against exact local PE exports and unwind function boundaries.
# @author  Hasegawa Jin
# @date    2026-10-23
import bisect
import ctypes as c
import json
import struct
from collections import Counter,defaultdict
from functools import lru_cache
from pathlib import Path
task=Path(__file__).resolve().parent
data=json.loads((task/'TraceEvents.json').read_text());schedule=json.loads((task/'ScheduleSummary.json').read_text())
dbg=c.WinDLL('dbghelp')
dbg.UnDecorateSymbolName.argtypes=[c.c_char_p,c.c_void_p,c.c_uint,c.c_uint];dbg.UnDecorateSymbolName.restype=c.c_uint
@lru_cache(None)
def name(symbol):
    buffer=c.create_string_buffer(8192)
    return buffer.value.decode('utf-8',errors='replace') if dbg.UnDecorateSymbolName(symbol.encode('ascii'),buffer,len(buffer),0x1000) else symbol
@lru_cache(None)
def pe(filename):
    path=task/'TraceRuntime'/filename
    if not path.exists() and filename.lower() in ('ntdll.dll','ucrtbase.dll','vcruntime140.dll','msvcp140.dll','kernel32.dll','kernelbase.dll'):
        path=Path('C:/Windows/System32')/filename
    if not path.exists():return None
    blob=path.read_bytes()
    def u(fmt,offset):return struct.unpack_from(fmt,blob,offset)
    pointer=u('<I',0x3c)[0];optional=pointer+24;section_count=u('<H',pointer+6)[0];optional_size=u('<H',pointer+20)[0]
    if u('<H',optional)[0]!=0x20b:return None
    sections=[u('<IIII',optional+optional_size+i*40+8) for i in range(section_count)]
    def offset(rva):
        for virtual_size,address,size,start in sections:
            if address<=rva<address+size:return start+rva-address
        raise ValueError(hex(rva))
    export_rva,export_size=u('<II',optional+112)
    names=defaultdict(list)
    if export_rva:
        directory=u('<IIHHIIIIIII',offset(export_rva));count=directory[7]
        for i in range(count):
            rva=u('<I',offset(directory[9])+i*4)[0];pos=offset(rva);symbol=blob[pos:blob.index(b'\0',pos)].decode('ascii')
            ordinal=u('<H',offset(directory[10])+i*2)[0];address=u('<I',offset(directory[8])+ordinal*4)[0]
            if not export_rva<=address<export_rva+export_size:names[address].append(symbol)
    unwind_rva,unwind_size=u('<II',optional+112+3*8)
    functions=[]
    if unwind_rva:
        start=offset(unwind_rva)
        functions=[u('<III',start+i)[:2] for i in range(0,unwind_size,12)]
    functions.sort()
    return names,functions,[row[0] for row in functions]
image_cache={}
def image(ip,pid):
    key=(ip,pid)
    if key not in image_cache:
        matches=[row for row in data['images'] if row['pid'] in (pid,0) and row['base']<=ip<row['base']+row['size']]
        image_cache[key]=matches[-1] if matches else None
    return image_cache[key]
@lru_cache(None)
def resolve(ip,pid):
    row=image(ip,pid)
    if row is None:return f'unknown+0x{ip:x}'
    filename=row['name'].replace('\\','/').split('/')[-1];rva=ip-row['base'];table=pe(filename)
    if table:
        names,functions,starts=table;index=bisect.bisect_right(starts,rva)-1
        if index>=0 and functions[index][0]<=rva<functions[index][1]:
            symbols=names.get(functions[index][0])
            if symbols:
                label=name(min(symbols,key=len));suffix=f' [ICF aliases:{len(symbols)}]' if len(symbols)>1 else ''
                return filename+'!'+label+suffix
    return f'{filename}+0x{rva:x}'
results=[]
for run,summary in zip(data['runs'],schedule['runs']):
    pid=run['config']['processId'];tid=run['config']['osThreadId'];frames=run['frames'];starts=[row['beginQpc'] for row in frames]
    tail={row['serial'] for row in summary['tailFrames']};leaf={'all':Counter(),'tail':Counter()};inclusive={'all':Counter(),'tail':Counter()};resolved=[]
    for sample in data['samples']:
        if sample['tid']!=tid:continue
        index=bisect.bisect_right(starts,sample['qpc'])-1
        if index<0 or sample['qpc']>=frames[index]['endQpc']:continue
        frame=frames[index];symbol=resolve(sample['ip'],pid);stack=list(dict.fromkeys(resolve(ip,pid) for ip in sample['stack']))
        leaf['all'][symbol]+=1;inclusive['all'].update(stack)
        if frame['serial'] in tail:leaf['tail'][symbol]+=1;inclusive['tail'].update(stack)
        resolved.append({'serial':frame['serial'],'qpc':sample['qpc'],'ip':sample['ip'],'symbol':symbol,'stack':stack})
    print('\n'+run['file'])
    for group in ('all','tail'):
        print(group,'leaf',leaf[group].most_common(12))
        print(group,'inclusive engine',[(symbol,count) for symbol,count in inclusive[group].most_common() if '!' in symbol and symbol.startswith('FBZZ')][:14])
    for frame in summary['tailFrames'][:2]:
        selected=[row for row in resolved if row['serial']==frame['serial']]
        print('SLOW FRAME',frame['serial'],frame['frameMs'],[(row['symbol'],[symbol for symbol in row['stack'] if symbol.startswith('FBZZ') and '!' in symbol]) for row in selected])
    results.append({'run':run['file'],'pid':pid,'tid':tid,'leaf':{key:dict(value) for key,value in leaf.items()},'inclusive':{key:dict(value) for key,value in inclusive.items()},'samples':resolved})
(task/'ResolvedFrameSamples.json').write_text(json.dumps({'method':'Exact local PE export start matched to runtime function begin; unexported functions remain module+RVA; ICF aliases flagged','runs':results},separators=(',',':')))
