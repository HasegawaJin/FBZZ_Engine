# @file    VerifyFinal.py
# @brief   Verify final source freshness, pinned exports and isolated benchmark binary identity.
# @author  Hasegawa Jin
# @date    2026-10-23
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

root = Path(__file__).resolve().parents[2]
task = Path(__file__).resolve().parent
label = sys.argv[1] if len(sys.argv) > 1 else 'Final'
spec = importlib.util.spec_from_file_location('pe_reader', root / 'Scratch/OceanSkinningSynchronization20261019/RegenerateLtoExports.py')
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)
maps = root / 'build/Release/lto-exports'
cache = (root / 'build/Release/CMakeCache.txt').read_text(encoding='utf-8-sig')
reader.require(re.search(r'^FBZZ_RELEASE_LTO:BOOL=ON$', cache, re.M), 'Final configuration is not LTO')
inputs = (maps / 'inputs.cmake').read_text(encoding='utf-8-sig')
paths = reader.cmake_list(inputs, 'FBZZ_LTO_EXPORT_PATHS')
hashes = dict(value.split('|', 1) for value in reader.cmake_list(inputs, 'FBZZ_LTO_EXPORT_INPUTS'))
reader.require(paths == reader.source_membership()[0], 'Source membership differs from pinned inputs')
reader.require(all(hashlib.sha256((root / name).read_bytes()).hexdigest() == hashes[name] for name in paths), 'Source freshness verification failed')
report = {'nativeInputs': len(paths), 'configuration': 'Release LTO', 'modules': {}, 'executables': {}}
for module in ('Math','Physics','Fluid','Core','Graphics','Engine'):
    name = 'FBZZ' + module
    planned = reader.def_entries((maps / (name + '.def')).read_text(encoding='utf-8-sig'))
    path = root / 'build/Release/Binaries/Release' / (name + '.dll')
    actual, timestamp = reader.pe_exports(path.read_bytes(), path.name)
    reader.require(set(planned) == set(actual), name + ' export names differ')
    reader.require(all(actual[symbol]['ordinal'] == entry['ordinal'] for symbol, entry in planned.items()), name + ' export ordinals differ')
    report['modules'][name] = {'exports': len(actual), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    staged = task / (label + '-Candidate') / path.name
    if staged.exists():
        reader.require(hashlib.sha256(staged.read_bytes()).hexdigest() == report['modules'][name]['sha256'], 'Staged candidate differs: ' + name)
for name in ('FBZZStaticMeshReuseBench.exe','FBZZTestsRayTracingEngine.exe'):
    a = hashlib.sha256((task / (label + '-Baseline') / name).read_bytes()).hexdigest()
    b = hashlib.sha256((task / (label + '-Candidate') / name).read_bytes()).hexdigest()
    reader.require(a == b, 'Benchmark executable differs: ' + name)
    report['executables'][name] = a
(task / ('FinalArtifactAudit.json' if label == 'Final' else label + '-ArtifactAudit.json')).write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'nativeInputs': len(paths), 'modules': len(report['modules']), 'identicalExecutables': len(report['executables'])}))
