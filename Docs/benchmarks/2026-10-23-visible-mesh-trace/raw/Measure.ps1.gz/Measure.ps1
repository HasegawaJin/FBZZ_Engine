# @file    Measure.ps1
# @brief   Compare visible-frame tail latency using the existing native-frame protocol and isolated DLLs.
# @author  Hasegawa Jin
# @date    2026-10-23
param([string] $Label='Reproduce',[switch] $Profile,[switch] $AllCases,[int] $ProfileSamples=600,[switch] $SameBinary)
$ErrorActionPreference='Stop'
$root='K:\FBZZ_Engine'
$task=Join-Path $root 'Scratch\VisibleMeshTrace20261023'
$bins=Join-Path $root 'build\Release\Binaries\Release'
Add-Type -Path "$root\Scratch\StaticMeshReuse20261023\TaskProcessSettings.cs"
New-Item -ItemType Directory -Force -Path "$task\Raw" | Out-Null
foreach($variant in @('Baseline','Candidate')){
    $stage="$task\$Label-$variant"
    if(-not(Test-Path -LiteralPath $stage)){
        New-Item -ItemType Directory -Path $stage | Out-Null
        $source=if($SameBinary){"$task\Original\Binaries"}elseif($Label -eq 'Reproduce'){
            if($variant -eq 'Baseline'){"$root\Scratch\MeshOnePercent20261023\Original\Binaries"}else{"$task\Original\Binaries"}
        }elseif($variant -eq 'Baseline'){"$task\Original\Binaries"}else{$bins}
        Get-ChildItem -LiteralPath $source -Filter '*.dll' -File | ForEach-Object{Copy-Item -LiteralPath $_.FullName -Destination $stage}
        foreach($name in @('FBZZTestsRayTracingEngine.exe','FBZZStaticMeshReuseBench.exe')){Copy-Item -LiteralPath "$bins\Tests\$name" -Destination $stage}
        Copy-Item -LiteralPath "$bins\Tests\D3D12" -Destination "$stage\D3D12" -Recurse
        Get-ChildItem -LiteralPath "$bins\Tests" -Filter '*.dll' -File | ForEach-Object{if(-not(Test-Path -LiteralPath "$stage\$($_.Name)")){Copy-Item -LiteralPath $_.FullName -Destination $stage}}
    }
}
$kind=if($Profile){'profile'}else{'gpu'}
$environment=[ordered]@{utc=[DateTime]::UtcNow.ToString('o');affinity=240;priority='High';highQosVerified=$true;paths=@{};cpu=(Get-CimInstance Win32_Processor|Select-Object Name,NumberOfCores,NumberOfLogicalProcessors);gpu=(Get-CimInstance Win32_VideoController|Select-Object Name,DriverVersion)}
foreach($variant in @('Baseline','Candidate')){$environment.paths[$variant]=@(Get-ChildItem -LiteralPath "$task\$Label-$variant" -File|ForEach-Object{@{name=$_.Name;sha256=(Get-FileHash -LiteralPath $_.FullName).Hash}})}
$environment|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$task\$Label-$kind-Environment.json" -Encoding UTF8
$cases=if($AllCases){@('AllVisible1000','OffscreenHeavy10000','OnePercentMovingOffscreenHeavy10000','AllMovingOffscreenHeavy10000','TwoViewsOppositeOffscreenHeavy10000')}else{@('AllVisible1000')}
$order=if($Profile){@('Baseline','Candidate')}else{@('Baseline','Candidate','Candidate','Baseline','Baseline','Candidate')}
$env:FBZZ_REGULAR_MESH_SAMPLES=if($Profile){[string]$ProfileSamples}else{'600'}
$env:FBZZ_REGULAR_MESH_TIMING_ONLY=if($Profile){'0'}else{'1'}
foreach($case in $cases){
    $env:FBZZ_REGULAR_MESH_WARMUP=if($case -eq 'AllVisible1000'){'600'}else{'120'}
    for($run=0;$run -lt $order.Length;++$run){
        $variant=$order[$run];$name="$Label-$kind-$case-r$run-$variant"
        $process=Start-Process -FilePath "$task\$Label-$variant\FBZZTestsRayTracingEngine.exe" -WindowStyle Hidden -PassThru -WorkingDirectory $root -ArgumentList @("--gtest_filter=RegularMeshRenderPerformanceTest.$case","--gtest_output=json:$task/Raw/$name-tests.json") -RedirectStandardOutput "$task\Raw\$name.out" -RedirectStandardError "$task\Raw\$name.err"
        $null=$process.Handle
        $process.ProcessorAffinity=[IntPtr]240;$process.PriorityClass='High'
        if([TaskProcessSettings]::SetHighQos($process.Id) -ne 0){throw 'HighQoS validation failed'}
        $process.WaitForExit()
        if($process.ExitCode -ne 0){throw "$name failed: $($process.ExitCode)"}
        $config=@([System.IO.File]::ReadAllLines("$task\Raw\$name.out")|Where-Object{$_.StartsWith('REGULAR_MESH_JSON ')}|ForEach-Object{$_.Substring(18)|ConvertFrom-Json}|Where-Object{$_.kind -eq 'config'})
        if($config.Count -ne 1 -or [System.IO.Path]::GetFullPath($config[0].enginePath) -ne [System.IO.Path]::GetFullPath("$task\$Label-$variant\FBZZEngine.dll")){throw 'Loaded module mismatch'}
        Write-Output "OK $name"
    }
}
[System.IO.File]::WriteAllText("$task\$Label-$kind.exit",'0')
exit 0
