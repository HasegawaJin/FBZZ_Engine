# @file    BoundaryEvidence.py
# @brief   Inspect complete per-frame CPU scopes without subtracting independent percentile statistics.
# @author  Hasegawa Jin
# @date    2026-10-23
import json
from pathlib import Path
task=Path(__file__).resolve().parent
result=[]
for path in sorted((task/'Raw').glob('*-profile-AllVisible1000-*.out')):
    records=[json.loads(line[18:]) for line in path.read_text(encoding='utf-8-sig',errors='replace').splitlines() if line.startswith('REGULAR_MESH_JSON ')]
    frames=[row for row in records if row['kind']=='cpu']
    rows=[]
    for frame in sorted(frames,key=lambda row:row['beginMs']+row['endMs'],reverse=True)[:4]:
        rows.append({name:frame[name] for name in ('serial','frameMs','beginMs','renderMs','endMs','profilerComplete','droppedSamples')}|{'scopes':{row['name']:row['inclusiveMs'] for row in frame['scopes']}})
    entry={'run':path.name,'completeFrames':sum(row['profilerComplete'] and row['droppedSamples']==0 for row in frames),'samples':len(frames),'slowBoundaryFrames':rows,'maximumBeginMs':max(row['beginMs'] for row in frames),'maximumFenceScopeMs':max(next((item['inclusiveMs'] for item in row['scopes'] if item['name']=='DX12Frame::WaitForFence'),0) for row in frames)}
    result.append(entry)
    print(path.name,'complete',entry['completeFrames'],'/',len(frames),'maxBegin',entry['maximumBeginMs'],'maxFence',entry['maximumFenceScopeMs'],'tail',rows[:1])
(task/'BoundaryEvidence.json').write_text(json.dumps(result,indent=2)+'\n')
