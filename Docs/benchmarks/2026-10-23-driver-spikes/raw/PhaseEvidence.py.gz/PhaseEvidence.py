# @file    PhaseEvidence.py
# @brief   Locate scheduler stalls within existing frame timing boundaries and count driver-stack attribution.
# @author  Hasegawa Jin
# @date    2026-10-23
import json
from pathlib import Path
task=Path(__file__).resolve().parent
data=json.loads((task/'TraceEvents.json').read_text())
resolved=json.loads((task/'ResolvedFrameSamples.json').read_text())
blocked=json.loads((task/'BlockingStacks.json').read_text())
schedule=json.loads((task/'ScheduleSummary.json').read_text())
result=[]
for run,symbols,waits in zip(data['runs'],resolved['runs'],blocked):
    rows=[];frequency=run['config']['qpcFrequency']
    for frame in sorted(run['frames'],key=lambda row:row['frameMs'],reverse=True)[:6]:
        value={name:frame[name] for name in ('serial','frameMs','renderMs','beginMs','endMs','waitCpuMs')}
        value['schedulerMs']=next(row['schedulerMs'] for item in schedule['runs'] if item['run']==run['file'] for row in item['tailFrames'] if row['serial']==frame['serial'])
        rows.append(value)
    for wait in waits['blockedIntervals']:
        frame=next(row for row in run['frames'] if row['serial']==wait['serial'])
        remaining=(frame['endQpc']-wait['beginQpc'])*1000/frequency
        wait['phase']='EndFrame' if remaining<=frame['endMs'] else 'RenderSystem' if remaining<=frame['endMs']+frame['renderMs'] else 'BeginFrame/earlier'
    driver=[sample for sample in symbols['samples'] if any(name.startswith(('nvwgf2umx.dll','nvlddmkm.sys')) for name in sample['stack'])]
    end_driver=[sample for sample in driver if any('DX12Context::EndFrame' in name for name in sample['stack'])]
    submit_driver=[sample for sample in driver if any('DX12Renderer::Submit' in name for name in sample['stack'])]
    entry={'run':run['file'],'tailFrames':rows,'driverInclusiveSamples':len(driver),'endFrameDriverSamples':len(end_driver),'submitDriverSamples':len(submit_driver),'blocking':waits['blockedIntervals']}
    result.append(entry)
    print(run['file'],'driver',len(driver),'end',len(end_driver),'submit',len(submit_driver),'tails',rows[:2],'blocks',[(row['serial'],row['blockedMs'],row['phase']) for row in waits['blockedIntervals'][:3]])
(task/'PhaseEvidence.json').write_text(json.dumps(result,indent=2)+'\n')
