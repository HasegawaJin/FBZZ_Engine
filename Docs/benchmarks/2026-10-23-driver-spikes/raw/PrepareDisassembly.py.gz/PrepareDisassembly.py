# @file    PrepareDisassembly.py
# @brief   Bound disassembly to the exact saved EndFrame function and enumerate sampled return addresses in that function.
# @author  Hasegawa Jin
# @date    2026-10-23
import contextlib
import importlib.util
import io
import json
import struct
from collections import Counter
from pathlib import Path
task=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('resolver',task/'ResolveTrace.py')
resolver=importlib.util.module_from_spec(spec)
with contextlib.redirect_stdout(io.StringIO()):spec.loader.exec_module(resolver)
names,functions,starts=resolver.pe('FBZZGraphics.dll')
begin=next(address for address,aliases in names.items() if any(name.startswith('?EndFrame@DX12Context@') for name in aliases))
end=next(right for left,right in functions if left==begin)
blob=(task/'TraceRuntime/FBZZGraphics.dll').read_bytes();optional=struct.unpack_from('<I',blob,0x3c)[0]+24
image_base=struct.unpack_from('<Q',blob,optional+24)[0]
counts=Counter();tails=[]
for run in resolver.data['runs']:
    pid=run['config']['processId'];tid=run['config']['osThreadId'];frames=run['frames']
    for sample in resolver.data['samples']:
        if sample['tid']!=tid:continue
        frame=next((row for row in frames if row['beginQpc']<=sample['qpc']<row['endQpc']),None)
        if frame is None:continue
        for ip in sample['stack']:
            image=resolver.image(ip,pid)
            if image is None or not image['name'].lower().endswith('fbzzgraphics.dll'):continue
            rva=ip-image['base']
            if begin<=rva<end:
                address=image_base+rva;counts[hex(address)]+=1
                if frame['serial'] in [row['serial'] for item in resolver.schedule['runs'] if item['run']==run['file'] for row in item['tailFrames']]:
                    tails.append({'run':run['file'],'serial':frame['serial'],'frameMs':frame['frameMs'],'returnAddress':hex(address),'leaf':resolver.resolve(sample['ip'],pid)})
result={'imageBase':hex(image_base),'begin':hex(image_base+begin),'end':hex(image_base+end),'sampledReturnAddresses':dict(counts),'tailSamples':tails}
(task/'EndFrameCallSites.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
