# @file    Disassemble.ps1
# @brief   Resolve driver stack call sites with the exact saved native image using the supported Visual Studio environment.
# @author  Hasegawa Jin
# @date    2026-10-23
$ErrorActionPreference='Stop'
& 'C:\Users\jinhs\AppData\Local\Programs\Python\Launcher\py.exe' "$PSScriptRoot\PrepareDisassembly.py"
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
$range=ConvertFrom-Json ([IO.File]::ReadAllText("$PSScriptRoot\EndFrameCallSites.json"))
. 'K:\FBZZ_Engine\Tools\VsEnvironment.ps1'
Import-VisualStudioEnvironment
& dumpbin /nologo /disasm:nobytes "/range:$($range.begin),$($range.end)" "$PSScriptRoot\TraceRuntime\FBZZGraphics.dll" | Set-Content -LiteralPath "$PSScriptRoot\GraphicsDisassembly.txt" -Encoding UTF8
exit $LASTEXITCODE
