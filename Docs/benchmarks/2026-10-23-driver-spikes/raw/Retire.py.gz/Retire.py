# @file    Retire.py
# @brief   Preserve the rejected experiment and restore only this task's private production files and pinned input map.
# @author  Hasegawa Jin
# @date    2026-10-23
import hashlib
import json
from pathlib import Path
task=Path(__file__).resolve().parent;root=task.parents[1]
files=['Projects/Graphics/src/Renderer/Platform/DX12/DX12Renderer.cpp','Projects/Graphics/src/Renderer/Platform/DX12/DX12Renderer.hpp']
saved=task/'Rejected';saved.mkdir(exist_ok=True)
manifest={}
for name in files:
    source=root/name;before=task/'Original'/name;destination=saved/name
    destination.parent.mkdir(parents=True,exist_ok=True)
    assert not destination.exists()
    data=source.read_bytes();destination.write_bytes(data)
    manifest[name]={'rejectedSha256':hashlib.sha256(data).hexdigest(),'restoredSha256':hashlib.sha256(before.read_bytes()).hexdigest()}
    source.write_bytes(before.read_bytes())
inputs=root/'build/Release/lto-exports/inputs.cmake'
(saved/'inputs.cmake').write_bytes(inputs.read_bytes())
inputs.write_bytes((task/'Original/lto-exports/inputs.cmake').read_bytes())
assert all((root/name).read_bytes()==(task/'Original'/name).read_bytes() for name in files)
assert inputs.read_bytes()==(task/'Original/lto-exports/inputs.cmake').read_bytes()
(task/'RetirementAudit.json').write_text(json.dumps({'decision':'rejected','productionFilesRestoredExactly':manifest,'inputMapRestoredExactly':True,'retainedProductionOptimizations':0},indent=2)+'\n')
print('Rejected candidate preserved; only its two private production files and input map restored exactly')
