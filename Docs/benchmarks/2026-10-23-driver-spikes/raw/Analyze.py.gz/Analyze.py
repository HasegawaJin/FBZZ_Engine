# @file    Analyze.py
# @brief   Validate per-frame geometry and image parity and summarize matched raw timing distributions.
# @author  Hasegawa Jin
# @date    2026-10-23
import json
from pathlib import Path
import statistics
import sys

task = Path(__file__).resolve().parent
raw = task / 'Raw'
label = sys.argv[1] if len(sys.argv) > 1 else 'Final'
kind = sys.argv[2] if len(sys.argv) > 2 else 'cpu'
smoke = 'smoke' in sys.argv[3:]
prefix = f'{label}-{kind}' + ('-smoke' if smoke else '')

def percentile(values, probability):
    values = sorted(values)
    position = (len(values) - 1) * probability
    index = int(position)
    return values[index] + (values[min(index + 1, len(values) - 1)] - values[index]) * (position - index)

def stats(values):
    return {'p50': statistics.median(values), 'p95': percentile(values, .95), 'p99': percentile(values, .99)}

groups = {}
if kind == 'cpu':
    for path in sorted(raw.glob(prefix + '-*.json')):
        if path.name.endswith('-tests.json'):
            continue
        data = json.loads(path.read_text(encoding='utf-8-sig'))
        assert data['valid'] and len(data['frames']) == data['samples'], path
        variant = 'Baseline' if path.stem.endswith('Baseline') else 'Candidate'
        assert data['enginePath'].replace('\\', '/').endswith(f'{label}-{variant}/FBZZEngine.dll'), path
        key = f"{data['objects']}-{data['mode']}"
        group = groups.setdefault(key, {'Baseline': [], 'Candidate': []})
        values = [frame['ms'] for frame in data['frames']]
        hashes = [frame['hash'] for frame in data['frames']]
        assert values and all(value > 0 for value in values), path
        group[variant].append({'path': path.name, 'values': values, 'hashes': hashes})
else:
    for path in sorted(raw.glob(prefix + '-*.out')):
        records = [json.loads(line[18:]) for line in path.read_text(encoding='utf-8-sig', errors='replace').splitlines() if line.startswith('REGULAR_MESH_JSON ')]
        configs = [record for record in records if record['kind'] == 'config']
        assert len(configs) == 1, path
        config = configs[0]
        variant = 'Baseline' if path.stem.endswith('Baseline') else 'Candidate'
        assert config['enginePath'].replace('\\', '/').endswith(f'{label}-{variant}/FBZZEngine.dll'), path
        cpu = [record for record in records if record['kind'] == 'cpu']
        validations = [record for record in records if record['kind'] == 'validation']
        assert len(cpu) == config['samples'] and len(validations) == 1 and validations[0]['nonBackgroundPixels'] > 0, path
        assert all(record['objects'] == config['objects'] and record['drawCalls'] > 0 for record in cpu), path
        complete_frames = sum(record['profilerComplete'] and record['droppedSamples'] == 0 for record in cpu)
        key = config['case']
        group = groups.setdefault(key, {'Baseline': [], 'Candidate': []})
        metrics = {metric: [record[metric] for record in cpu] for metric in ('frameMs', 'renderMs', 'waitCpuMs', 'beginMs', 'endMs', 'firstViewRenderMs', 'secondViewRenderMs')}
        scope_names = sorted({scope['name'] for record in cpu for scope in record['scopes']}) if complete_frames == len(cpu) else []
        for name in scope_names:
            metrics[name] = [next((scope['inclusiveMs'] for scope in record['scopes'] if scope['name'] == name), 0) for record in cpu]
        pass_names = sorted({p['name'] for record in cpu for p in record['passes']})
        for name in pass_names:
            metrics['pass:' + name] = [next((p['cpuMs'] for p in record['passes'] if p['name'] == name), 0) for record in cpu]
        gpu = [record for record in records if record['kind'] == 'gpuPass']
        for name in sorted({record['name'] for record in gpu}):
            metrics['gpu:' + name] = [record['gpuMs'] for record in gpu if record['name'] == name]
        group[variant].append({'path': path.name, 'values': metrics['frameMs'], 'metrics': metrics,
            'profileCompleteFrames': complete_frames, 'profileFrames': len(cpu),
            'profileDroppedSamples': sum(record['droppedSamples'] for record in cpu),
            'validation': validations[0], 'counters': [(record['objects'], record['frustumCulled'], record['drawCalls'], record['triangles'], record['firstViewDrawCalls']) for record in cpu]})

summary = {'label': label, 'kind': kind, 'smoke': smoke, 'groups': {}}
expected_runs = 1 if smoke or kind == 'profile' else 3
for key, group in groups.items():
    assert all(len(group[variant]) == expected_runs for variant in ('Baseline', 'Candidate')), key
    baseline = group['Baseline'][0]
    for variant in ('Baseline', 'Candidate'):
        for run in group[variant]:
            if kind == 'cpu':
                assert run['hashes'] == baseline['hashes'], (key, run['path'], 'Geometry hash mismatch')
            else:
                assert run['validation']['pixelHash'] == baseline['validation']['pixelHash'], (key, run['path'], 'Image mismatch')
                assert run['counters'] == baseline['counters'], (key, run['path'], 'Submission mismatch')
    result = {'parity': True, 'variants': {}}
    for variant in ('Baseline', 'Candidate'):
        runs = group[variant]
        result['variants'][variant] = {'runP50': [statistics.median(run['values']) for run in runs],
            'pooled': stats([value for run in runs for value in run['values']]), 'files': [run['path'] for run in runs]}
        if kind != 'cpu':
            metrics = set.intersection(*(set(run['metrics']) for run in runs))
            result['variants'][variant]['metrics'] = {name: stats([value for run in runs for value in run['metrics'][name]]) for name in sorted(metrics)}
            result['variants'][variant]['profileCompleteFrames'] = sum(run['profileCompleteFrames'] for run in runs)
            result['variants'][variant]['profileFrames'] = sum(run['profileFrames'] for run in runs)
            result['variants'][variant]['profileDroppedSamples'] = sum(run['profileDroppedSamples'] for run in runs)
    before = statistics.median(result['variants']['Baseline']['runP50'])
    after = statistics.median(result['variants']['Candidate']['runP50'])
    result.update({'baselineMedianMs': before, 'candidateMedianMs': after, 'changePercent': (after / before - 1) * 100})
    summary['groups'][key] = result
    print(f'{key}: {before:.6f} -> {after:.6f} ms ({result["changePercent"]:+.2f}%), parity=PASS')
assert groups, 'No measurements found'
(task / (prefix + '-Summary.json')).write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
