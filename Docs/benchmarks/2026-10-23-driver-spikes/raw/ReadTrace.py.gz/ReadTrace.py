# @file    ReadTrace.py
# @brief   Join raw ETW scheduler and sampled instruction events to exact native frame intervals.
# @author  Hasegawa Jin
# @date    2026-10-23
import bisect
import ctypes as c
import importlib.util
import json
import statistics
import struct
import uuid
from collections import Counter,defaultdict
from pathlib import Path
task=Path(__file__).resolve().parent
root=task.parents[1]
spec=importlib.util.spec_from_file_location('etw',root/'Scratch/OceanSkinningSynchronization20261019/AnalyzeEtwScheduleV2.py')
etw=importlib.util.module_from_spec(spec);spec.loader.exec_module(etw)
etw.abi_check()
runs=[]
for path in sorted((task/'TraceV2').glob('r?.out')):
    rows=[json.loads(line[18:]) for line in path.read_text(encoding='utf-8-sig',errors='replace').splitlines() if line.startswith('REGULAR_MESH_JSON ')]
    config=next(row for row in rows if row['kind']=='config')
    cpu=[row for row in rows if row['kind']=='cpu']
    assert len(cpu)==600
    frequency=config['qpcFrequency']
    for row in cpu:
        row['beginQpc']=round(row['frameBeginMs']*frequency/1000)
        row['endQpc']=round(row['frameEndMs']*frequency/1000)
        assert abs((row['endQpc']-row['beginQpc'])*1000/frequency-row['frameMs'])<.0003
    runs.append({'file':path.name,'config':config,'frames':cpu})
assert len(runs)==3 and len({run['config']['qpcFrequency'] for run in runs})==1
targets={run['config']['osThreadId'] for run in runs}
pids={run['config']['processId'] for run in runs}
perf=uuid.UUID('ce1dbfb4-137e-4da6-87b0-3f59aa102cbc').bytes_le
image=uuid.UUID('2cb15d1d-5fc1-11d2-abe1-00a0c911f518').bytes_le
stack=uuid.UUID('def2fe46-7bd6-4b80-bd94-f57fe20d0ce3').bytes_le
api=c.WinDLL('advapi32',use_last_error=True)
api.OpenTraceW.argtypes=[c.POINTER(etw.EVENT_TRACE_LOGFILEW)];api.OpenTraceW.restype=etw.U64
api.ProcessTrace.argtypes=[c.POINTER(etw.U64),etw.U32,c.c_void_p,c.c_void_p];api.ProcessTrace.restype=etw.U32
api.CloseTrace.argtypes=[etw.U64];api.CloseTrace.restype=etw.U32
tdh=c.WinDLL('tdh',use_last_error=True)
class Descriptor(c.Structure):
    _fields_=[('name',etw.U64),('index',etw.U32),('reserved',etw.U32)]
tdh.TdhGetPropertySize.argtypes=[c.POINTER(etw.EVENT_RECORD),etw.U32,c.c_void_p,etw.U32,c.POINTER(Descriptor),c.POINTER(etw.U32)]
tdh.TdhGetProperty.argtypes=[c.POINTER(etw.EVENT_RECORD),etw.U32,c.c_void_p,etw.U32,c.POINTER(Descriptor),etw.U32,c.c_void_p]
def prop(pointer,name):
    text=c.create_unicode_buffer(name);desc=Descriptor(c.addressof(text),0xffffffff,0);size=etw.U32()
    result=tdh.TdhGetPropertySize(pointer,0,None,1,c.byref(desc),c.byref(size))
    if result:return None
    data=c.create_string_buffer(size.value)
    if tdh.TdhGetProperty(pointer,0,None,1,c.byref(desc),size,data):return None
    return data.raw
events=[];samples=[];images=[];stacks={};errors=[]
counts=Counter();schemas=Counter();loss={'events':0,'buffers':0};first=[None]
@etw.EVENT_CALLBACK
def callback(pointer):
    if errors:return
    try:
        record=pointer.contents;header=record.EventHeader
        guid=bytes(header.ProviderId);op=int(header.EventDescriptor.Opcode);version=int(header.EventDescriptor.Version)
        qpc=int(header.TimeStamp);length=int(record.UserDataLength)
        counts['allEvents']+=1
        if qpc>0:first[0]=qpc if first[0] is None else min(first[0],qpc)
        if guid==etw.THREAD_GUID:
            rows,schema=etw.decode_thread_event(record,targets)
            events.extend(rows)
        elif guid==perf and op==46:
            # @see https://learn.microsoft.com/en-us/windows/win32/etw/sampledprofile Pointer-sized IP followed by ThreadId.
            schemas[('sample',version,length)]+=1
            if length>=12:
                ip,tid=struct.unpack('<QI',c.string_at(record.UserData,12))
                if tid in targets:samples.append({'qpc':qpc,'tid':tid,'ip':ip,'cpu':int(record.BufferContext.ProcessorIndex)})
        elif guid==image and op in (2,3,4,10):
            schemas[('image',version,length)]+=1
            if version in (2,3) and length>=20:
                base,size,pid=struct.unpack('<QQI',c.string_at(record.UserData,20))
                if pid in pids or pid==0:
                    name=prop(pointer,'FileName')
                    if name:images.append({'qpc':qpc,'pid':pid,'base':base,'size':size,'name':name.decode('utf-16-le').rstrip('\0'),'opcode':op})
                    else:counts['imageNameUnresolved']+=1
        elif guid==stack:
            schemas[('stack',op,version,length)]+=1
            if op==32 and length>=16 and (length-16)%8==0:
                data=c.string_at(record.UserData,length)
                original,pid,tid=struct.unpack_from('<QII',data)
                if tid in targets:
                    frames=struct.unpack_from('<'+'Q'*((length-16)//8),data,16)
                    stacks.setdefault((original,tid),[]).extend(frames)
    except BaseException as error:errors.append(str(error))
@etw.BUFFER_CALLBACK
def buffer(pointer):
    current=pointer.contents
    loss['events']=max(loss['events'],int(current.EventsLost),int(current.LogfileHeader.EventsLost))
    loss['buffers']=max(loss['buffers'],int(current.LogfileHeader.BuffersLost))
    return int(not errors)
log=etw.EVENT_TRACE_LOGFILEW();log.LogFileName=str(task/'TraceV2/Cpu.etl')
log.ProcessTraceMode=etw.PROCESS_TRACE_MODE_EVENT_RECORD|etw.PROCESS_TRACE_MODE_RAW_TIMESTAMP
log.EventRecordCallback=callback;log.BufferCallback=buffer
handle=api.OpenTraceW(c.byref(log));assert handle!=0xffffffffffffffff,c.get_last_error()
header={name:int(getattr(log.LogfileHeader,name)) for name in ('ReservedFlags','PerfFreq','EventsLost','BuffersLost','PointerSize','StartTime','EndTime','BootTime')}
assert header['ReservedFlags']==1 and header['PerfFreq']==frequency
try:result=api.ProcessTrace((etw.U64*1)(handle),1,None,None)
finally:close=api.CloseTrace(handle)
assert not errors,errors
assert result==close==0 and loss['events']==loss['buffers']==0,(result,close,loss)
for sample in samples:sample['stack']=stacks.get((sample['qpc'],sample['tid']),[])
(task/'SchedulerStacks.json').write_text(json.dumps([{'event':row,'stack':stacks.get((row[0],row[1]),[])} for row in events if row[2]=='out'],separators=(',',':')))
metadata={'header':header,'loss':loss,'eventsRead':counts['allEvents'],'counts':dict(counts),'firstEventQpc':first[0],'schemas':[{'schema':list(key),'count':value} for key,value in schemas.items()],'targetSamples':len(samples),'targetStacks':len(stacks),'images':len(images),'targetSchedulerEvents':len(events)}
(task/'TraceEvents.json').write_text(json.dumps({'metadata':metadata,'runs':runs,'samples':samples,'images':images,'scheduler':events},separators=(',',':')))
summary=[]
for run in runs:
    config=run['config'];pid=config['processId'];tid=config['osThreadId'];frames=run['frames']
    segments=etw.reconstruct(events,{tid:{'main'}},pid,min(row['beginQpc'] for row in frames),max(row['endQpc'] for row in frames))
    for row in frames:
        tally=Counter()
        for segment in segments:
            if segment['osThreadId']!=tid:continue
            overlap=max(0,min(segment['endQpc'],row['endQpc'])-max(segment['beginQpc'],row['beginQpc']))
            if overlap:tally[segment['state']]+=overlap*1000/frequency
        row['schedulerMs']=dict(tally)
        row['samples']=sum(sample['tid']==tid and row['beginQpc']<=sample['qpc']<row['endQpc'] for sample in samples)
    tail=sorted(frames,key=lambda row:row['frameMs'],reverse=True)[:6]
    entry={'run':run['file'],'pid':pid,'tid':tid,'medianFrameMs':statistics.median(row['frameMs'] for row in frames),'tailFrames':tail,'schedulerTotalsMs':{key:sum(row['schedulerMs'].get(key,0) for row in frames) for key in ('scheduled','ready','blocked','unknown')}}
    summary.append(entry)
    print(run['file'],'median',entry['medianFrameMs'],'tail',[(row['serial'],round(row['frameMs'],3),row['schedulerMs']) for row in tail])
(task/'ScheduleSummary.json').write_text(json.dumps({'metadata':metadata,'runs':summary},indent=2)+'\n')
print(json.dumps({key:metadata[key] for key in ('header','loss','eventsRead','counts','targetSamples','targetStacks','images','targetSchedulerEvents')}))
